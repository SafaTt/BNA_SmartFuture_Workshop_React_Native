const colors = {
    primary : "#18A775",
    second : "#E7E7E7",
    gris : "#F4F4F4",
    bleu: "#04566E",
    grey : "#868686"
}

export default colors;