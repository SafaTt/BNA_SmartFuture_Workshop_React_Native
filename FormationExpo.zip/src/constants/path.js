const baseURL = "http://172.31.99.213:1234";

const path = {
    auth : `${baseURL}/api/auth`,
    user : `${baseURL}/api/user`,
    virement : `${baseURL}/api/virement`
}

export default path;